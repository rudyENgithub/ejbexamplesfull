package com.rudysorto.ejb.server;

public interface Imagenes {
	
	
	String IMG_1 = "https://images.pexels.com/photos/7099642/pexels-photo-7099642.jpeg?cs=srgb&dl=pexels-julia-volk-7099642.jpg&fm=jpg";
	String IMG_2 = "https://images.pexels.com/photos/11642205/pexels-photo-11642205.jpeg?cs=srgb&dl=pexels-haticebaran-11642205.jpg&fm=jpg";
	String IMG_3 = "https://images.pexels.com/photos/9611344/pexels-photo-9611344.jpeg?cs=srgb&dl=pexels-jenny-uhling-9611344.jpg&fm=jpg";
	String IMG_4 = "https://images.pexels.com/photos/11648215/pexels-photo-11648215.jpeg?cs=srgb&dl=pexels-kira-schwarz-11648215.jpg&fm=jpg";
	String IMG_5 = "https://images.pexels.com/photos/5732693/pexels-photo-5732693.jpeg?cs=srgb&dl=pexels-jonathan-borba-5732693.jpg&fm=jpg";
	String IMG_6 = "https://images.pexels.com/photos/5206261/pexels-photo-5206261.jpeg?cs=srgb&dl=pexels-julia-volk-5206261.jpg&fm=jpg";
	String IMG_7 = "https://images.pexels.com/photos/6481652/pexels-photo-6481652.jpeg?cs=srgb&dl=pexels-anna-tarazevich-6481652.jpg&fm=jpg";
	String IMG_8 = "https://images.pexels.com/photos/11391862/pexels-photo-11391862.jpeg?cs=srgb&dl=pexels-amar-preciado-11391862.jpg&fm=jpg";
}
