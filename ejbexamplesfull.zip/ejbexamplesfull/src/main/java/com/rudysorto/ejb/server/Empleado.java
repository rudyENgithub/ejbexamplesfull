package com.rudysorto.ejb.server;

public class Empleado {
	
	private int clave;
	private String nombre;
	private String correo;
	private String cargo;
	private double sueldo;
	
	public Empleado(int clave, String nombre, String correo, String cargo, double sueldo) {
	
		this.clave = clave;
		this.nombre = nombre;
		this.correo = correo;
		this.cargo = cargo;
		this.sueldo = sueldo;
	}

	public int getClave() {
		return clave;
	}

	public String getNombre() {
		return nombre;
	}

	public String getCorreo() {
		return correo;
	}

	public String getCargo() {
		return cargo;
	}

	public double getSueldo() {
		return sueldo;
	}
	
	
	
	

}
