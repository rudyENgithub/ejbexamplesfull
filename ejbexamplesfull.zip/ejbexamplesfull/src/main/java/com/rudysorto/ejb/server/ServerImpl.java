package com.rudysorto.ejb.server;

import java.util.ArrayList;

import javax.ejb.Stateless;

@Stateless(name="servicioConsulta")
public class ServerImpl implements Servidor, Imagenes {
	
	private static ArrayList<Empleado> listPersonas(){
		
		ArrayList<Empleado> lista = new ArrayList<Empleado>();
		lista.add(new Empleado(1, "Juan Perez", "1@gmail.com", "programador", 2500));
		lista.add(new Empleado(2, "Mia Hanz", "2@gmail.com", "diseñador", 1500));

		lista.add(new Empleado(3, "Meche Sosa", "3@gmail.com", "PM", 3500));

		lista.add(new Empleado(4, "Gaby Plata", "4@gmail.com", "programador", 2500));

		lista.add(new Empleado(6, "Andrea Parada", "6@gmail.com", "programador", 2500));

		lista.add(new Empleado(5, "Eli  Ayala", "5@gmail.com", "programador", 2500));

		lista.add(new Empleado(7, "Julian Sorto", "7@gmail.com", "diseñador", 1500));

		lista.add(new Empleado(8, "Andrez Rovira", "8@gmail.com", "PM", 3500));

		
		return lista;
		
	}
	
	private static String img(int id) {
		String op = null;
		
		switch (id) {
		case 1:
			op=IMG_1;
			break;
		case 2:
			op=IMG_2;		
			break;
		case 3:
			op=IMG_3;
			break;
		case 4:
			op=IMG_4;
			break;
		case 5:
			op=IMG_5;
			break;
		case 6:
			op=IMG_6;
			break;
		case 7:
			op=IMG_7;
			break;
		case 8:
			op=IMG_8;
			break;
		}
		
		return op;
	}
	
	private static String[] getPersona(int id) {
		String[] resultado = new String[5];
		resultado[0]= "<img src="+img(listPersonas().get(id-1).getClave())+" width=270 height=200 />";
		resultado[1]= "Nombre: "+listPersonas().get(id-1).getNombre();
		resultado[2]= "Correo: "+listPersonas().get(id-1).getCorreo();
		resultado[3]= "Cargo: "+listPersonas().get(id-1).getCargo();
		resultado[4]= "Sueldo: "+listPersonas().get(id-1).getSueldo();
		return resultado;
		
	}
	
	

	public String[] consultar(int id) {
		if(id<listPersonas().size()+1) {
			return getPersona(id);
		}
		else {
			String[] vacio = new String[5];
			vacio[0]= "No existen datos de empleado para este ID";
			vacio[1]=vacio[2]=vacio[3]=vacio[4]="";
			return vacio;
			
			
		}
	}

}
