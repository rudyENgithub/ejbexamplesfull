package com.rudysorto.ejb.client;

import java.io.IOException;
import java.io.PrintWriter;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rudysorto.ejb.server.Servidor;

@WebServlet(urlPatterns="/consultar")
public class Client extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@EJB
	private Servidor servicio;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		int cod =  Integer.parseInt(req.getParameter("cod"));
		PrintWriter pw = resp.getWriter();
		
		String[] resultado = servicio.consultar(cod);
		
		pw.println("<html>");
		
		pw.println("<head>");
		pw.println("</head>");
		
		pw.println("<body>");
		pw.println("<div>");

		pw.println("<h2> Datos del Empleado </h2>");
		pw.println(resultado[0]);
		pw.println("<h3>" + resultado[1] +"</h3>");
		pw.println("<h3>" + resultado[2] +"</h3>");
		pw.println("<h3>" + resultado[3] +"</h3>");
		pw.println("<h3>" + resultado[4] +"</h3>");


		pw.println("</div>");

		
		
		pw.println("</body>");
		
		pw.println("</html>");
		pw.flush();
		pw.close();
		
	}

}
